"use client";

import {
  ChangeEvent,
  FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import { Calendar, Camera, Loader2, LogOut, Trash2 } from "lucide-react";
import { useAppDispatch, useAppSelector } from "@/shared/hooks/useReduxHooks";
import {
  deleteAccountThunk,
  logoutThunk,
  refreshTokenThunk,
  updateProfileThunk,
} from "@/entities/user/api/UserApiThunk";
import { setError } from "@/entities/user/slice/userSlice";
import { ConfirmModal } from "@/shared/ui/ConfirmModal/ConfirmModal";
import { AppNav } from "@/widgets/appShell/AppNav";
import { BrandLogo } from "@/widgets/appShell/BrandLogo";
import { isAdmin } from "@/shared/lib/permissions";
import { useAutoDismiss } from "@/shared/hooks/useAutoDismiss";
import { FadeAlert } from "@/shared/ui/FadeAlert/FadeAlert";
import { getRoleLabel } from "@/shared/lib/roleLabels";
import { formatPlatformSince } from "@/shared/lib/formatPlatformSince";
import { getNameInitials } from "@/shared/lib/getNameInitials";
import "../classes/page.css";
import "./page.css";

function getApiOrigin() {
  const raw = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";

  return raw.replace(/\/+$/, "").replace(/\/api$/i, "");
}

function getAvatarSrc(avatarUrl?: string | null) {
  if (!avatarUrl) {
    return "";
  }

  if (avatarUrl.startsWith("http")) {
    return avatarUrl;
  }

  return `${getApiOrigin()}${avatarUrl}`;
}

function splitName(fullName: string) {
  const parts = fullName.trim().split(/\s+/).filter(Boolean);

  return {
    firstName: parts[0] || "",
    lastName: parts[1] || "",
    patronymic: parts.slice(2).join(" "),
  };
}

export default function ProfilePage() {
  const router = useRouter();
  const dispatch = useAppDispatch();

  const firstNameInputRef = useRef<HTMLInputElement | null>(null);
  const lastNameInputRef = useRef<HTMLInputElement | null>(null);
  const patronymicInputRef = useRef<HTMLInputElement | null>(null);
  const phoneInputRef = useRef<HTMLInputElement | null>(null);

  const user = useAppSelector((s) => s.user.user);
  const isInitialized = useAppSelector((s) => s.user.isInitialized);
  const isLoading = useAppSelector((s) => s.user.isLoading);
  const authError = useAppSelector((s) => s.user.error);

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [patronymic, setPatronymic] = useState("");
  const [phone, setPhone] = useState("");

  const [isFirstNameEditable, setIsFirstNameEditable] = useState(false);
  const [isLastNameEditable, setIsLastNameEditable] = useState(false);
  const [isPatronymicEditable, setIsPatronymicEditable] = useState(false);
  const [isPhoneEditable, setIsPhoneEditable] = useState(false);

  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    if (user) {
      setAuthChecked(true);
      return;
    }

    if (!isInitialized) {
      return;
    }

    dispatch(refreshTokenThunk())
      .unwrap()
      .then(() => {
        setAuthChecked(true);
      })
      .catch(() => {
        router.replace("/");
      });
  }, [dispatch, isInitialized, router, user]);

  useEffect(() => {
    if (user) {
      const parsedName = splitName(user.name);

      setFirstName(parsedName.firstName);
      setLastName(parsedName.lastName);
      setPatronymic(parsedName.patronymic);
      setPhone(user.phone?.trim() ?? "");

      setIsFirstNameEditable(false);
      setIsLastNameEditable(false);
      setIsPatronymicEditable(false);
      setIsPhoneEditable(false);

      setAvatarFile(null);
      setAvatarPreview("");
    }
  }, [user]);

  const avatarSrc = useMemo(() => {
    if (avatarPreview) {
      return avatarPreview;
    }

    return getAvatarSrc(user?.avatarUrl);
  }, [avatarPreview, user?.avatarUrl]);

  const fullName = useMemo(() => {
    return [firstName, lastName, patronymic]
      .map((part) => part.trim())
      .filter(Boolean)
      .join(" ");
  }, [firstName, lastName, patronymic]);

  const avatarInitials = useMemo(
    () => getNameInitials(firstName, lastName, user?.name),
    [firstName, lastName, user?.name],
  );

  const platformSince = useMemo(
    () => formatPlatformSince(user?.createdAt),
    [user?.createdAt],
  );

  const roleLabel = useMemo(() => getRoleLabel(user?.role), [user?.role]);

  const showAdminLink = isAdmin(user?.role);

  useAutoDismiss(Boolean(successMessage), () => {
    setSuccessMessage("");
  });

  const focusFieldEnd = useCallback((input: HTMLInputElement | null) => {
    if (!input) {
      return;
    }

    const end = input.value.length;
    input.focus();
    input.setSelectionRange(end, end);
  }, []);

  const handleLogout = useCallback(() => {
    dispatch(logoutThunk())
      .unwrap()
      .then(() => {
        router.push("/");
      })
      .catch(() => {});
  }, [dispatch, router]);

  const handleOpenDelete = useCallback(() => {
    dispatch(setError(null));
    setDeleteModalOpen(true);
  }, [dispatch]);

  const handleCloseDelete = useCallback(() => {
    if (!isLoading) {
      dispatch(setError(null));
      setDeleteModalOpen(false);
    }
  }, [dispatch, isLoading]);

  const handleConfirmDelete = useCallback(() => {
    dispatch(deleteAccountThunk())
      .unwrap()
      .then(() => {
        setDeleteModalOpen(false);
        router.push("/");
      })
      .catch(() => {});
  }, [dispatch, router]);

  const handleAvatarChange = useCallback(
    (event: ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0] || null;

      setSuccessMessage("");
      dispatch(setError(null));

      if (!file) {
        setAvatarFile(null);
        setAvatarPreview("");
        return;
      }

      if (!file.type.startsWith("image/")) {
        dispatch(setError("Можно загрузить только изображение"));
        event.target.value = "";
        return;
      }

      if (file.size > 2 * 1024 * 1024) {
        dispatch(setError("Файл должен быть не больше 2 МБ"));
        event.target.value = "";
        return;
      }

      setAvatarFile(file);
      setAvatarPreview(URL.createObjectURL(file));
    },
    [dispatch],
  );

  const handleSubmit = useCallback(
    (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();

      setSuccessMessage("");
      dispatch(setError(null));

      if (fullName.trim().length < 2) {
        dispatch(setError("ФИО должно быть минимум 2 символа"));
        return;
      }

      const phoneTrimmed = phone.trim();
      if (phoneTrimmed) {
        const digits = phoneTrimmed.replace(/\D/g, "");
        if (digits.length < 10 || digits.length > 15) {
          dispatch(setError("Телефон должен содержать от 10 до 15 цифр"));
          return;
        }
      }

      dispatch(
        updateProfileThunk({
          name: fullName,
          phone: phoneTrimmed,
          avatar: avatarFile,
        }),
      )
        .unwrap()
        .then(() => {
          setAvatarFile(null);
          setAvatarPreview("");
          setIsFirstNameEditable(false);
          setIsLastNameEditable(false);
          setIsPatronymicEditable(false);
          setIsPhoneEditable(false);
          setSuccessMessage("Профиль сохранён");
        })
        .catch(() => {});
    },
    [avatarFile, dispatch, fullName, phone],
  );

  if (!isInitialized || !authChecked || !user) {
    return (
      <main className="classes-page profile-page">
        <p className="profile-state">Загрузка…</p>
      </main>
    );
  }

  return (
    <main className="classes-page profile-page">
      {deleteModalOpen ? (
        <ConfirmModal
          title="Вы точно хотите удалить свой аккаунт?"
          lines={["Внимание! Все ваши данные будут удалены безвозвратно."]}
          confirmLabel="Подтвердить"
          cancelLabel="Отмена"
          onConfirm={handleConfirmDelete}
          onCancel={handleCloseDelete}
          isBusy={isLoading}
          errorMessage={authError}
        />
      ) : null}

      <section className="profile-shell classes-shell">
        <aside className="profile-sidebar classes-sidebar">
          <BrandLogo />

          <AppNav active="profile" showAdminLink={showAdminLink} />

          <div className="sidebar-info">
            <div className="shield-mini">🛡</div>
            <div>
              <h3>Настройки профиля</h3>
              <p>Измените личные данные и фото.</p>
            </div>
          </div>
        </aside>

        <section className="profile-main classes-content">
          <header className="profile-page-header">
            <h1>Профиль</h1>
            <button
              type="button"
              className="profile-logout-btn"
              onClick={handleLogout}
              disabled={isLoading}
            >
              {isLoading && !deleteModalOpen ? (
                <Loader2 className="profile-btn-spin" size={18} aria-hidden />
              ) : (
                <LogOut size={18} aria-hidden />
              )}
              Выйти
            </button>
          </header>

          <form className="profile-form" onSubmit={handleSubmit}>
            <section className="profile-hero">
              <label className="profile-avatar">
                {avatarSrc ? (
                  <img src={avatarSrc} alt="" />
                ) : (
                  <span className="profile-avatar-initials" aria-hidden>
                    {avatarInitials}
                  </span>
                )}

                <input
                  className="profile-avatar-input"
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  onChange={handleAvatarChange}
                />

                <span className="profile-avatar-camera" aria-hidden>
                  <Camera size={18} strokeWidth={2} />
                </span>
              </label>

              <div className="profile-hero-text">
                <div className="profile-name-row">
                  <h2>{fullName || user.name}</h2>
                  <span className="profile-role-badge">{roleLabel}</span>
                </div>
                <p className="profile-username">@{user.username}</p>
                {platformSince ? (
                  <p className="profile-member-since">
                    <Calendar size={16} strokeWidth={2} aria-hidden />
                    {platformSince}
                  </p>
                ) : null}
              </div>
            </section>

            <section className="profile-section">
              <h3>Личная информация</h3>

              <div className="profile-fields">
                <div className="profile-field">
                  <span className="profile-field-label">Имя</span>
                  <input
                    ref={firstNameInputRef}
                    className="profile-field-input"
                    value={firstName}
                    readOnly={!isFirstNameEditable}
                    onChange={(event) => {
                      setFirstName(event.target.value);
                      setSuccessMessage("");
                    }}
                    onBlur={() => setIsFirstNameEditable(false)}
                    placeholder="Имя"
                  />
                  <button
                    type="button"
                    className="profile-field-edit"
                    aria-label="Редактировать имя"
                    onClick={() => {
                      setIsFirstNameEditable(true);
                      setTimeout(
                        () => focusFieldEnd(firstNameInputRef.current),
                        0,
                      );
                    }}
                  >
                    ✎
                  </button>
                </div>

                <div className="profile-field">
                  <span className="profile-field-label">Фамилия</span>
                  <input
                    ref={lastNameInputRef}
                    className="profile-field-input"
                    value={lastName}
                    readOnly={!isLastNameEditable}
                    onChange={(event) => {
                      setLastName(event.target.value);
                      setSuccessMessage("");
                    }}
                    onBlur={() => setIsLastNameEditable(false)}
                    placeholder="Фамилия"
                  />
                  <button
                    type="button"
                    className="profile-field-edit"
                    aria-label="Редактировать фамилию"
                    onClick={() => {
                      setIsLastNameEditable(true);
                      setTimeout(
                        () => focusFieldEnd(lastNameInputRef.current),
                        0,
                      );
                    }}
                  >
                    ✎
                  </button>
                </div>

                <div className="profile-field profile-field--wide">
                  <span className="profile-field-label">
                    Отчество (необязательно)
                  </span>
                  <input
                    ref={patronymicInputRef}
                    className="profile-field-input"
                    value={
                      !isPatronymicEditable && !patronymic.trim()
                        ? "Не указано"
                        : patronymic
                    }
                    readOnly={!isPatronymicEditable}
                    onChange={(event) => {
                      setPatronymic(event.target.value);
                      setSuccessMessage("");
                    }}
                    onBlur={() => setIsPatronymicEditable(false)}
                    placeholder="Не указано"
                  />
                  <button
                    type="button"
                    className="profile-field-edit"
                    aria-label="Редактировать отчество"
                    onClick={() => {
                      setIsPatronymicEditable(true);
                      setTimeout(
                        () => focusFieldEnd(patronymicInputRef.current),
                        0,
                      );
                    }}
                  >
                    ✎
                  </button>
                </div>

                <div className="profile-field">
                  <span className="profile-field-label">Email</span>
                  <input
                    className="profile-field-input profile-field-input--readonly"
                    value={user.email}
                    readOnly
                    tabIndex={-1}
                  />
                </div>

                <div className="profile-field">
                  <span className="profile-field-label">
                    Телефон (необязательно)
                  </span>
                  <input
                    ref={phoneInputRef}
                    className="profile-field-input"
                    type="tel"
                    value={
                      !isPhoneEditable && !phone.trim()
                        ? "Не указано"
                        : phone
                    }
                    readOnly={!isPhoneEditable}
                    onChange={(event) => {
                      setPhone(event.target.value);
                      setSuccessMessage("");
                    }}
                    onBlur={() => setIsPhoneEditable(false)}
                    placeholder="+7 900 000-00-00"
                    autoComplete="tel"
                  />
                  <button
                    type="button"
                    className="profile-field-edit"
                    aria-label="Редактировать телефон"
                    onClick={() => {
                      setIsPhoneEditable(true);
                      setTimeout(() => focusFieldEnd(phoneInputRef.current), 0);
                    }}
                  >
                    ✎
                  </button>
                </div>
              </div>

              <div className="profile-privacy-banner" role="note">
                <span className="profile-privacy-icon" aria-hidden>
                  i
                </span>
                <p>
                  Эти данные видны только вам и не отображаются другим
                  пользователям
                </p>
              </div>

              <FadeAlert text={authError} className="profile-error" />
              <FadeAlert
                text={successMessage || null}
                className="profile-success"
                role="status"
              />

              <div className="profile-save-row">
                <button
                  type="submit"
                  className="profile-save-btn"
                  disabled={isLoading}
                >
                  {isLoading && !deleteModalOpen ? (
                    <Loader2 className="profile-btn-spin" size={18} aria-hidden />
                  ) : null}
                  Сохранить изменения
                </button>
              </div>
            </section>
          </form>

          <section className="profile-danger" aria-labelledby="profile-danger-title">
            <div className="profile-danger-copy">
              <h3 id="profile-danger-title">Опасная зона</h3>
              <p>
                Удаление аккаунта приведёт к потере всех ваших данных без
                возможности восстановления
              </p>
            </div>
            <button
              type="button"
              className="profile-delete-btn"
              onClick={handleOpenDelete}
              disabled={isLoading}
            >
              <Trash2 size={18} aria-hidden />
              Удалить аккаунт
            </button>
          </section>
        </section>
      </section>
    </main>
  );
}
