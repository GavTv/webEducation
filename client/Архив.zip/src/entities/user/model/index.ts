export type UserRole = "student" | "teacher" | "admin";

export type UserType = {
  id: number;
  name: string;
  email: string;
  username: string;
  role?: UserRole;
  avatarUrl?: string | null;
  phone?: string | null;
  createdAt?: string;
  updatedAt?: string;
};

export type UserWithTokenType = {
  user: UserType;
  accessToken: string;
};

export type UserLoginData = {
  email: string;
  password: string;
  rememberMe?: boolean;
};

export type UserRegisterData = UserLoginData & {
  name: string;
  username: string;
};

export type UserStateType = {
  user: UserType | null;
  isLoading: boolean;
  error: string | null;
  isInitialized: boolean;
  /** Краткое уведомление после входа/регистрации; сбрасывается через 5 с в UI */
  authSuccessToast: string | null;
};

export const initialUserState: UserStateType = {
  user: null,
  isLoading: false,
  error: null,
  isInitialized: false,
  authSuccessToast: null,
};
